defmodule FlightexTest do
  use ExUnit.Case
end
