# Elixir Fundamentals

- [x] Module Introduction
- [x] Development Environment
- [x] Why study Functional and Elixir?
- [x] Basic Operators and Types
- [x] Atoms and Documentation
- [x] Lists
- [x] Tuples
- [x] Maps
- [x] Introduction to Pattern Matching 1
- [x] Introduction to Pattern Matching 2
- [x] Sum List Project
- [x] Challenge: Using recursion
- [x] Challenge: Filtering in lists

