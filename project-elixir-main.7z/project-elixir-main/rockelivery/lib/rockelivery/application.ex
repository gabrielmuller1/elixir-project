defmodule Rockelivery.Application do
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application

  def start(_type, _args) do
    children = [
      # Start the Ecto repository
      Rockelivery.Repo,
      # Start the Telemetry supervisor
      RockeliveryWeb.Telemetry,
      # Start the PubSub system
      {Phoenix.PubSub, name: Rockelivery.PubSub},
      # Start the Endpoint (http/https)
      RockeliveryWeb.Endpoint,
      # Start a worker by calling: Rockelivery.Worker.start_link(arg)
      # {Rockelivery.Worker, arg}
      {Rockelivery.Orders.ReportRunner, []}
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: Rockelivery.Supervisor]
    Supervisor.start_link(children, opts)
  end

  # Tell Phoenix to update the endpoint configuration
  # whenever the application is updated.
  def config_change(changed, _new, removed) do
    RockeliveryWeb.Endpoint.config_change(changed, removed)
    :ok
  end
end
